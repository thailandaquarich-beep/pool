import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq, or } from "drizzle-orm";
import { signToken } from "../lib/jwt.js";
import { authenticate } from "../middlewares/auth.js";

const router = Router();

function formatUser(user: typeof usersTable.$inferSelect) {
  const { passwordHash: _, ...rest } = user;
  return { ...rest, createdAt: rest.createdAt.toISOString() };
}

// POST /auth/register
router.post("/register", async (req, res) => {
  try {
    const { firstName, lastName, houseNumber, phone, email, username, password, role } = req.body;

    if (!firstName || !lastName || !houseNumber || !phone || !email || !username || !password) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const existing = await db
      .select()
      .from(usersTable)
      .where(or(eq(usersTable.email, email), eq(usersTable.username, username)))
      .limit(1);

    if (existing.length > 0) {
      return res.status(400).json({ error: "Email or username already exists" });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const [user] = await db
      .insert(usersTable)
      .values({ firstName, lastName, houseNumber, phone, email, username, passwordHash, role: role || "member" })
      .returning();

    const token = signToken({ userId: user.id, username: user.username, role: user.role });

    return res.status(201).json({ token, user: formatUser(user) });
  } catch (err) {
    return res.status(500).json({ error: "Registration failed" });
  }
});

// POST /auth/login
router.post("/login", async (req, res) => {
  try {
    const { usernameOrEmail, password, rememberMe } = req.body;

    if (!usernameOrEmail || !password) {
      return res.status(400).json({ error: "Username/email and password are required" });
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(or(eq(usersTable.email, usernameOrEmail), eq(usersTable.username, usernameOrEmail)))
      .limit(1);

    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = signToken({ userId: user.id, username: user.username, role: user.role }, !!rememberMe);

    return res.json({ token, user: formatUser(user) });
  } catch (err) {
    return res.status(500).json({ error: "Login failed" });
  }
});

// POST /auth/logout
router.post("/logout", (req, res) => {
  return res.json({ message: "Logged out successfully" });
});

// GET /auth/me
router.get("/me", authenticate, async (req, res) => {
  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.user!.userId))
      .limit(1);

    if (!user) {
      return res.status(401).json({ error: "User not found" });
    }

    return res.json(formatUser(user));
  } catch {
    return res.status(500).json({ error: "Failed to get user" });
  }
});

export default router;
