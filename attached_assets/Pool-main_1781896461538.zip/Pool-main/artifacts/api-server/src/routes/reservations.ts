import { Router } from "express";
import { db, reservationsTable, usersTable, settingsTable } from "@workspace/db";
import { eq, and, gte, lte, sql, or, inArray } from "drizzle-orm";
import { authenticate, requireAdmin } from "../middlewares/auth.js";

const router = Router();

function formatReservation(r: typeof reservationsTable.$inferSelect, user: typeof usersTable.$inferSelect) {
  const { passwordHash: _, ...safeUser } = user;
  return {
    ...r,
    date: r.date,
    createdAt: r.createdAt.toISOString(),
    user: { ...safeUser, createdAt: safeUser.createdAt.toISOString() },
  };
}

function timeToMinutes(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function timesOverlap(s1: string, e1: string, s2: string, e2: string) {
  return timeToMinutes(s1) < timeToMinutes(e2) && timeToMinutes(e1) > timeToMinutes(s2);
}

async function getSettings() {
  const rows = await db.select().from(settingsTable).limit(1);
  if (rows.length > 0) return rows[0];
  const [defaultSettings] = await db.insert(settingsTable).values({}).returning();
  return defaultSettings;
}

// GET /reservations/available-slots
router.get("/available-slots", authenticate, async (req, res) => {
  try {
    const date = req.query.date as string;
    if (!date) return res.status(400).json({ error: "date is required" });

    const settings = await getSettings();
    const openMins = timeToMinutes(settings.openTime);
    const closeMins = timeToMinutes(settings.closeTime);
    const duration = settings.slotDurationMinutes;

    const slots = [];
    for (let start = openMins; start + duration <= closeMins; start += duration) {
      const startTime = `${String(Math.floor(start / 60)).padStart(2, "0")}:${String(start % 60).padStart(2, "0")}`;
      const endMins = start + duration;
      const endTime = `${String(Math.floor(endMins / 60)).padStart(2, "0")}:${String(endMins % 60).padStart(2, "0")}`;

      const existingReservations = await db
        .select()
        .from(reservationsTable)
        .where(
          and(
            eq(reservationsTable.date, date),
            inArray(reservationsTable.status, ["confirmed", "pending"])
          )
        );

      const overlapping = existingReservations.filter((r) =>
        timesOverlap(startTime, endTime, r.startTime, r.endTime)
      );

      const currentPeople = overlapping.reduce((sum, r) => sum + r.numberOfPeople, 0);

      slots.push({
        startTime,
        endTime,
        available: !settings.maintenanceMode && settings.bookingEnabled && currentPeople < settings.maxPeoplePerSlot,
        currentPeople,
        maxPeople: settings.maxPeoplePerSlot,
      });
    }

    return res.json(slots);
  } catch {
    return res.status(500).json({ error: "Failed to get available slots" });
  }
});

// GET /reservations/my
router.get("/my", authenticate, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(100, parseInt(req.query.limit as string) || 20);
    const offset = (page - 1) * limit;
    const status = req.query.status as string | undefined;

    const conditions = [eq(reservationsTable.userId, req.user!.userId)];
    if (status) {
      conditions.push(eq(reservationsTable.status, status as "confirmed" | "pending" | "cancelled" | "maintenance"));
    }

    const reservationsRaw = await db
      .select()
      .from(reservationsTable)
      .where(and(...conditions))
      .orderBy(sql`${reservationsTable.date} DESC, ${reservationsTable.startTime} DESC`)
      .limit(limit)
      .offset(offset);

    const users = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.user!.userId))
      .limit(1);

    const user = users[0];
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(reservationsTable)
      .where(and(...conditions));

    return res.json({
      reservations: reservationsRaw.map((r) => formatReservation(r, user)),
      total: count,
      page,
      totalPages: Math.ceil(count / limit),
    });
  } catch {
    return res.status(500).json({ error: "Failed to get reservations" });
  }
});

// GET /reservations/upcoming
router.get("/upcoming", authenticate, async (req, res) => {
  try {
    const today = new Date().toISOString().split("T")[0];

    const reservationsRaw = await db
      .select()
      .from(reservationsTable)
      .where(
        and(
          eq(reservationsTable.userId, req.user!.userId),
          gte(reservationsTable.date, today),
          inArray(reservationsTable.status, ["confirmed", "pending"])
        )
      )
      .orderBy(reservationsTable.date, reservationsTable.startTime)
      .limit(5);

    const users = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.user!.userId))
      .limit(1);

    const user = users[0];
    return res.json(reservationsRaw.map((r) => formatReservation(r, user)));
  } catch {
    return res.status(500).json({ error: "Failed to get upcoming reservations" });
  }
});

// GET /reservations
router.get("/", authenticate, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(100, parseInt(req.query.limit as string) || 20);
    const offset = (page - 1) * limit;

    const conditions: ReturnType<typeof eq>[] = [];

    if (req.user!.role !== "admin") {
      conditions.push(eq(reservationsTable.userId, req.user!.userId));
    }

    const date = req.query.date as string | undefined;
    const startDate = req.query.startDate as string | undefined;
    const endDate = req.query.endDate as string | undefined;
    const status = req.query.status as string | undefined;
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;

    if (date) conditions.push(eq(reservationsTable.date, date));
    if (startDate) conditions.push(gte(reservationsTable.date, startDate));
    if (endDate) conditions.push(lte(reservationsTable.date, endDate));
    if (status) conditions.push(eq(reservationsTable.status, status as "confirmed" | "pending" | "cancelled" | "maintenance"));
    if (userId && req.user!.role === "admin") conditions.push(eq(reservationsTable.userId, userId));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const reservationsRaw = await db
      .select()
      .from(reservationsTable)
      .where(whereClause)
      .orderBy(sql`${reservationsTable.date} DESC, ${reservationsTable.startTime} DESC`)
      .limit(limit)
      .offset(offset);

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(reservationsTable)
      .where(whereClause);

    const userIds = [...new Set(reservationsRaw.map((r) => r.userId))];
    const usersData = userIds.length > 0
      ? await db.select().from(usersTable).where(inArray(usersTable.id, userIds))
      : [];

    const usersMap = Object.fromEntries(usersData.map((u) => [u.id, u]));

    return res.json({
      reservations: reservationsRaw.map((r) => formatReservation(r, usersMap[r.userId])),
      total: count,
      page,
      totalPages: Math.ceil(count / limit),
    });
  } catch (err) {
    return res.status(500).json({ error: "Failed to list reservations" });
  }
});

// POST /reservations
router.post("/", authenticate, async (req, res) => {
  try {
    const { date, startTime, endTime, numberOfPeople, notes } = req.body;
    const settings = await getSettings();

    if (!settings.bookingEnabled) {
      return res.status(400).json({ error: "Booking is currently disabled" });
    }
    if (settings.maintenanceMode) {
      return res.status(400).json({ error: settings.maintenanceMessage || "Pool is under maintenance" });
    }

    const today = new Date().toISOString().split("T")[0];
    if (date < today) {
      return res.status(400).json({ error: "Cannot book in the past" });
    }

    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + settings.maxAdvanceDays);
    const maxDateStr = maxDate.toISOString().split("T")[0];
    if (date > maxDateStr) {
      return res.status(400).json({ error: `Cannot book more than ${settings.maxAdvanceDays} days in advance` });
    }

    const overlapping = await db
      .select()
      .from(reservationsTable)
      .where(
        and(
          eq(reservationsTable.date, date),
          inArray(reservationsTable.status, ["confirmed", "pending"])
        )
      );

    const conflicting = overlapping.filter((r) =>
      timesOverlap(startTime, endTime, r.startTime, r.endTime)
    );
    const currentPeople = conflicting.reduce((sum, r) => sum + r.numberOfPeople, 0);

    if (currentPeople + numberOfPeople > settings.maxPeoplePerSlot) {
      return res.status(400).json({ error: "This time slot is full" });
    }

    const [reservation] = await db
      .insert(reservationsTable)
      .values({ userId: req.user!.userId, date, startTime, endTime, numberOfPeople, status: "confirmed", notes })
      .returning();

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.userId)).limit(1);
    return res.status(201).json(formatReservation(reservation, user));
  } catch {
    return res.status(500).json({ error: "Failed to create reservation" });
  }
});

// GET /reservations/:id
router.get("/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [reservation] = await db.select().from(reservationsTable).where(eq(reservationsTable.id, id)).limit(1);

    if (!reservation) return res.status(404).json({ error: "Reservation not found" });
    if (req.user!.role !== "admin" && reservation.userId !== req.user!.userId) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, reservation.userId)).limit(1);
    return res.json(formatReservation(reservation, user));
  } catch {
    return res.status(500).json({ error: "Failed to get reservation" });
  }
});

// PATCH /reservations/:id
router.patch("/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [existing] = await db.select().from(reservationsTable).where(eq(reservationsTable.id, id)).limit(1);

    if (!existing) return res.status(404).json({ error: "Reservation not found" });
    if (req.user!.role !== "admin" && existing.userId !== req.user!.userId) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { status, notes, numberOfPeople } = req.body;
    const updates: Partial<typeof reservationsTable.$inferInsert> = {};
    if (status) updates.status = status;
    if (notes !== undefined) updates.notes = notes;
    if (numberOfPeople) updates.numberOfPeople = numberOfPeople;

    const [updated] = await db.update(reservationsTable).set(updates).where(eq(reservationsTable.id, id)).returning();
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, updated.userId)).limit(1);

    return res.json(formatReservation(updated, user));
  } catch {
    return res.status(500).json({ error: "Failed to update reservation" });
  }
});

// DELETE /reservations/:id
router.delete("/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [existing] = await db.select().from(reservationsTable).where(eq(reservationsTable.id, id)).limit(1);

    if (!existing) return res.status(404).json({ error: "Reservation not found" });
    if (req.user!.role !== "admin" && existing.userId !== req.user!.userId) {
      return res.status(403).json({ error: "Forbidden" });
    }

    await db.update(reservationsTable).set({ status: "cancelled" }).where(eq(reservationsTable.id, id));
    return res.json({ message: "Reservation cancelled" });
  } catch {
    return res.status(500).json({ error: "Failed to cancel reservation" });
  }
});

export default router;
