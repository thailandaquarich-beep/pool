---
name: FormField in Dialog bug
description: Using shadcn Form/FormField inside Radix Dialog portals causes useFormField runtime crash
---

## Rule
Never use shadcn's `Form`, `FormField`, `FormItem`, `FormLabel`, `FormControl`, `FormMessage` components inside a `Dialog` in this project.

**Why:** Radix Dialog renders in a portal. Under certain rendering conditions (HMR, strict mode), the FormFieldContext is lost and `useFormField` throws "useFormField should be used within <FormField>".

**How to apply:** Use simple `useState` controlled forms inside dialogs — same pattern as `admin/members.tsx`. Use `<Label>`, `<Input>`, `<Textarea>`, `<Select>` etc. directly with `value` and `onChange` props.
