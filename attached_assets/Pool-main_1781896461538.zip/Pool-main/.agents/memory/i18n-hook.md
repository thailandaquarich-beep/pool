---
name: i18n hook
description: The translation hook name in this project
---

## Rule
Use `useTranslation` from `@/i18n` — NOT `useLanguage` (that file does not exist).

```ts
import { useTranslation } from "@/i18n";
const { t } = useTranslation();
```
