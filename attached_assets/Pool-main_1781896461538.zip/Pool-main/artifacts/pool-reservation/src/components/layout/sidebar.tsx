import { FC } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "@/i18n";
import {
  LayoutDashboard,
  CalendarDays,
  CalendarPlus,
  Calendar,
  User,
  Settings,
  Users,
  LogOut,
  Droplets,
  Building2,
  GraduationCap,
  Bell
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export const Sidebar: FC = () => {
  const [location] = useLocation();
  const { user, isAdmin, logout } = useAuth();
  const { t } = useTranslation();

  const memberLinks = [
    { href: "/dashboard", label: t("nav.dashboard"), icon: LayoutDashboard },
    { href: "/reservations", label: t("nav.reservations"), icon: CalendarDays },
    { href: "/book", label: t("nav.book"), icon: CalendarPlus },
    { href: "/calendar", label: t("nav.calendar"), icon: Calendar },
    { href: "/profile", label: t("nav.profile"), icon: User },
  ];

  const adminLinks = [
    { href: "/admin", label: t("nav.admin.dashboard"), icon: LayoutDashboard },
    { href: "/admin/reservations", label: t("nav.admin.reservations"), icon: CalendarDays },
    { href: "/admin/members", label: t("nav.admin.members"), icon: Users },
    { href: "/admin/facilities", label: t("nav.admin.facilities"), icon: Building2 },
    { href: "/admin/instructors", label: t("nav.admin.instructors"), icon: GraduationCap },
    { href: "/admin/announcements", label: t("nav.admin.announcements"), icon: Bell },
    { href: "/admin/settings", label: t("nav.admin.settings"), icon: Settings },
  ];

  const links = isAdmin ? adminLinks : memberLinks;

  const initials = user ? `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() : "U";

  return (
    <aside className="hidden md:flex w-64 flex-col bg-sidebar border-r border-sidebar-border h-[100dvh] sticky top-0">
      <div className="p-4 flex items-center gap-3 border-b border-sidebar-border">
        <img src="/aquarich-logo.png" alt="Aquarich" className="w-10 h-10 object-contain flex-shrink-0" />
        <div>
          <h2 className="font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">Aquarich</h2>
          <p className="text-xs text-sidebar-foreground/60">Reservation System</p>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        <div className="text-xs font-semibold text-muted-foreground mb-3 px-3">
          {isAdmin ? "ADMIN" : "MEMBER"}
        </div>
        {links.map((link) => {
          const isActive = location === link.href;
          const Icon = link.icon;
          return (
            <Link key={link.href} href={link.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}
              >
                <div className={cn(
                  "p-1 rounded-full",
                  isActive ? "bg-white/20" : ""
                )}>
                  <Icon className="w-4 h-4" />
                </div>
                {link.label}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border space-y-4">
        {user && (
          <div className="flex items-center gap-3 px-3">
            <div className="w-9 h-9 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center shrink-0">
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-sidebar-foreground truncate">
                {user.firstName} {user.lastName}
              </div>
              <div className="text-xs text-sidebar-foreground/60 truncate">
                {t("nav.house")} {user.houseNumber}
              </div>
            </div>
          </div>
        )}
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground hover:text-destructive hover:bg-destructive/10"
          onClick={logout}
        >
          <LogOut className="w-5 h-5 mr-3" />
          {t("nav.logout")}
        </Button>
      </div>
    </aside>
  );
};