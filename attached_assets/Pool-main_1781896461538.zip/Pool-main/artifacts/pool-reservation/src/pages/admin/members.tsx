import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListUsers,
  useCreateUser,
  useUpdateUser,
  useDeleteUser,
  useResetUserPassword,
  getListUsersQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, Pencil, Trash2, KeyRound, ChevronLeft, ChevronRight } from "lucide-react";

type User = {
  id: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  phone: string | null;
  houseNumber: string | null;
  role: string;
  createdAt: string;
};

const RoleBadge = ({ role }: { role: string }) => {
  const isAdmin = role === "admin";
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${
        isAdmin
          ? "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300"
          : "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300"
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${isAdmin ? "bg-blue-500" : "bg-emerald-500"}`} />
      {isAdmin ? "Admin" : "Member"}
    </span>
  );
};

const UserAvatar = ({ firstName, lastName }: { firstName: string; lastName: string }) => {
  const initials = `${firstName?.[0] ?? ""}${lastName?.[0] ?? ""}`.toUpperCase();
  return (
    <div className="w-8 h-8 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0">
      {initials}
    </div>
  );
};

type AddForm = {
  firstName: string;
  lastName: string;
  houseNumber: string;
  phone: string;
  email: string;
  username: string;
  password: string;
  role: string;
};

type EditForm = {
  firstName: string;
  lastName: string;
  houseNumber: string;
  phone: string;
  email: string;
  role: string;
};

export function AdminMembers() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);

  // Dialogs
  const [addOpen, setAddOpen] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);
  const [deleteUser, setDeleteUser] = useState<User | null>(null);
  const [resetUser, setResetUser] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState("");

  // Forms
  const [addForm, setAddForm] = useState<AddForm>({
    firstName: "", lastName: "", houseNumber: "", phone: "",
    email: "", username: "", password: "", role: "member",
  });
  const [editForm, setEditForm] = useState<EditForm>({
    firstName: "", lastName: "", houseNumber: "", phone: "", email: "", role: "member",
  });

  const params = { page, limit: 15, ...(debouncedSearch ? { search: debouncedSearch } : {}) };
  const { data, isLoading } = useListUsers(params);
  const users: User[] = (data as any)?.users ?? [];
  const totalPages: number = (data as any)?.totalPages ?? 1;
  const total: number = (data as any)?.total ?? 0;

  const invalidate = () => qc.invalidateQueries({ queryKey: getListUsersQueryKey() });

  const createMutation = useCreateUser({
    mutation: {
      onSuccess: () => { toast({ title: "เพิ่มสมาชิกสำเร็จ" }); setAddOpen(false); invalidate(); resetAddForm(); },
      onError: (e: any) => toast({ title: "เกิดข้อผิดพลาด", description: e?.message, variant: "destructive" }),
    },
  });

  const updateMutation = useUpdateUser({
    mutation: {
      onSuccess: () => { toast({ title: "แก้ไขสมาชิกสำเร็จ" }); setEditUser(null); invalidate(); },
      onError: (e: any) => toast({ title: "เกิดข้อผิดพลาด", description: e?.message, variant: "destructive" }),
    },
  });

  const deleteMutation = useDeleteUser({
    mutation: {
      onSuccess: () => { toast({ title: "ลบสมาชิกสำเร็จ" }); setDeleteUser(null); invalidate(); },
      onError: (e: any) => toast({ title: "เกิดข้อผิดพลาด", description: e?.message, variant: "destructive" }),
    },
  });

  const resetMutation = useResetUserPassword({
    mutation: {
      onSuccess: () => { toast({ title: "รีเซ็ตรหัสผ่านสำเร็จ" }); setResetUser(null); setNewPassword(""); },
      onError: (e: any) => toast({ title: "เกิดข้อผิดพลาด", description: e?.message, variant: "destructive" }),
    },
  });

  function resetAddForm() {
    setAddForm({ firstName: "", lastName: "", houseNumber: "", phone: "", email: "", username: "", password: "", role: "member" });
  }

  function openEdit(user: User) {
    setEditForm({
      firstName: user.firstName, lastName: user.lastName,
      houseNumber: user.houseNumber ?? "", phone: user.phone ?? "",
      email: user.email, role: user.role,
    });
    setEditUser(user);
  }

  let searchTimer: ReturnType<typeof setTimeout>;
  function handleSearchChange(val: string) {
    setSearch(val);
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { setDebouncedSearch(val); setPage(1); }, 400);
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">จัดการสมาชิก</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            สมาชิกทั้งหมด {total} คน
          </p>
        </div>
        <Button onClick={() => setAddOpen(true)} className="gap-2" data-testid="add-member-btn">
          <Plus className="w-4 h-4" /> เพิ่มสมาชิก
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="ค้นหาชื่อ, อีเมล, บ้านเลขที่..."
          value={search}
          onChange={(e) => handleSearchChange(e.target.value)}
          data-testid="search-input"
        />
      </div>

      {/* Table */}
      <div className="rounded-xl border border-border bg-card overflow-hidden shadow-sm">
        {isLoading ? (
          <div className="p-12 text-center text-muted-foreground">กำลังโหลด...</div>
        ) : users.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground">ไม่พบสมาชิก</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-left px-4 py-3 font-semibold text-muted-foreground">สมาชิก</th>
                  <th className="text-left px-4 py-3 font-semibold text-muted-foreground">บ้านเลขที่</th>
                  <th className="text-left px-4 py-3 font-semibold text-muted-foreground">เบอร์โทร</th>
                  <th className="text-left px-4 py-3 font-semibold text-muted-foreground">อีเมล</th>
                  <th className="text-left px-4 py-3 font-semibold text-muted-foreground">ระดับ</th>
                  <th className="text-left px-4 py-3 font-semibold text-muted-foreground">วันที่สมัคร</th>
                  <th className="text-right px-4 py-3 font-semibold text-muted-foreground">การดำเนินการ</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <UserAvatar firstName={user.firstName} lastName={user.lastName} />
                        <div>
                          <p className="font-medium text-foreground">{user.firstName} {user.lastName}</p>
                          <p className="text-xs text-muted-foreground">@{user.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-foreground">{user.houseNumber ?? "-"}</td>
                    <td className="px-4 py-3 text-foreground">{user.phone ?? "-"}</td>
                    <td className="px-4 py-3 text-foreground">{user.email}</td>
                    <td className="px-4 py-3"><RoleBadge role={user.role} /></td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">
                      {new Date(user.createdAt).toLocaleDateString("th-TH")}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(user)} title="แก้ไข" data-testid={`edit-btn-${user.id}`}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { setResetUser(user); setNewPassword(""); }} title="รีเซ็ตรหัสผ่าน" data-testid={`reset-btn-${user.id}`}>
                          <KeyRound className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteUser(user)} title="ลบ" data-testid={`delete-btn-${user.id}`}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>หน้า {page} จาก {totalPages}</span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Add Member Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>เพิ่มสมาชิกใหม่</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>ชื่อ *</Label>
              <Input value={addForm.firstName} onChange={e => setAddForm(f => ({ ...f, firstName: e.target.value }))} placeholder="ชื่อ" data-testid="add-firstName" />
            </div>
            <div className="space-y-1.5">
              <Label>นามสกุล *</Label>
              <Input value={addForm.lastName} onChange={e => setAddForm(f => ({ ...f, lastName: e.target.value }))} placeholder="นามสกุล" data-testid="add-lastName" />
            </div>
            <div className="space-y-1.5">
              <Label>บ้านเลขที่</Label>
              <Input value={addForm.houseNumber} onChange={e => setAddForm(f => ({ ...f, houseNumber: e.target.value }))} placeholder="เช่น 123/4" data-testid="add-houseNumber" />
            </div>
            <div className="space-y-1.5">
              <Label>เบอร์โทร</Label>
              <Input value={addForm.phone} onChange={e => setAddForm(f => ({ ...f, phone: e.target.value }))} placeholder="0812345678" data-testid="add-phone" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>อีเมล *</Label>
              <Input type="email" value={addForm.email} onChange={e => setAddForm(f => ({ ...f, email: e.target.value }))} placeholder="email@example.com" data-testid="add-email" />
            </div>
            <div className="space-y-1.5">
              <Label>ชื่อผู้ใช้ *</Label>
              <Input value={addForm.username} onChange={e => setAddForm(f => ({ ...f, username: e.target.value }))} placeholder="username" data-testid="add-username" />
            </div>
            <div className="space-y-1.5">
              <Label>รหัสผ่าน *</Label>
              <Input type="password" value={addForm.password} onChange={e => setAddForm(f => ({ ...f, password: e.target.value }))} placeholder="รหัสผ่าน" data-testid="add-password" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>ระดับสิทธิ์</Label>
              <Select value={addForm.role} onValueChange={val => setAddForm(f => ({ ...f, role: val }))}>
                <SelectTrigger data-testid="add-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="member">Member — สมาชิกทั่วไป</SelectItem>
                  <SelectItem value="admin">Admin — ผู้ดูแลระบบ</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>ยกเลิก</Button>
            <Button
              data-testid="add-submit"
              disabled={createMutation.isPending || !addForm.firstName || !addForm.lastName || !addForm.email || !addForm.username || !addForm.password}
              onClick={() => createMutation.mutate({ data: addForm as any })}
            >
              {createMutation.isPending ? "กำลังบันทึก..." : "เพิ่มสมาชิก"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Member Dialog */}
      <Dialog open={!!editUser} onOpenChange={open => !open && setEditUser(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>แก้ไขข้อมูลสมาชิก</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>ชื่อ</Label>
              <Input value={editForm.firstName} onChange={e => setEditForm(f => ({ ...f, firstName: e.target.value }))} data-testid="edit-firstName" />
            </div>
            <div className="space-y-1.5">
              <Label>นามสกุล</Label>
              <Input value={editForm.lastName} onChange={e => setEditForm(f => ({ ...f, lastName: e.target.value }))} data-testid="edit-lastName" />
            </div>
            <div className="space-y-1.5">
              <Label>บ้านเลขที่</Label>
              <Input value={editForm.houseNumber} onChange={e => setEditForm(f => ({ ...f, houseNumber: e.target.value }))} data-testid="edit-houseNumber" />
            </div>
            <div className="space-y-1.5">
              <Label>เบอร์โทร</Label>
              <Input value={editForm.phone} onChange={e => setEditForm(f => ({ ...f, phone: e.target.value }))} data-testid="edit-phone" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>อีเมล</Label>
              <Input type="email" value={editForm.email} onChange={e => setEditForm(f => ({ ...f, email: e.target.value }))} data-testid="edit-email" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>ระดับสิทธิ์ (Rank)</Label>
              <Select value={editForm.role} onValueChange={val => setEditForm(f => ({ ...f, role: val }))}>
                <SelectTrigger data-testid="edit-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="member">Member — สมาชิกทั่วไป</SelectItem>
                  <SelectItem value="admin">Admin — ผู้ดูแลระบบ</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">
                เปลี่ยนเป็น Admin เพื่อให้สิทธิ์เข้าถึงหน้าจัดการระบบ
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditUser(null)}>ยกเลิก</Button>
            <Button
              data-testid="edit-submit"
              disabled={updateMutation.isPending}
              onClick={() => editUser && updateMutation.mutate({ id: editUser.id, data: editForm as any })}
            >
              {updateMutation.isPending ? "กำลังบันทึก..." : "บันทึก"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={!!resetUser} onOpenChange={open => !open && setResetUser(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>รีเซ็ตรหัสผ่าน</DialogTitle>
          </DialogHeader>
          {resetUser && (
            <p className="text-sm text-muted-foreground">
              รีเซ็ตรหัสผ่านสำหรับ <span className="font-semibold text-foreground">{resetUser.firstName} {resetUser.lastName}</span>
            </p>
          )}
          <div className="space-y-1.5">
            <Label>รหัสผ่านใหม่</Label>
            <Input
              type="password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="รหัสผ่านใหม่"
              data-testid="reset-password-input"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResetUser(null)}>ยกเลิก</Button>
            <Button
              data-testid="reset-submit"
              disabled={resetMutation.isPending || newPassword.length < 6}
              onClick={() => resetUser && resetMutation.mutate({ id: resetUser.id, data: { newPassword } })}
            >
              {resetMutation.isPending ? "กำลังรีเซ็ต..." : "รีเซ็ตรหัสผ่าน"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteUser} onOpenChange={open => !open && setDeleteUser(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ยืนยันการลบสมาชิก</AlertDialogTitle>
            <AlertDialogDescription>
              คุณต้องการลบ <span className="font-semibold">{deleteUser?.firstName} {deleteUser?.lastName}</span> ออกจากระบบ?<br />
              การดำเนินการนี้ไม่สามารถย้อนกลับได้
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ยกเลิก</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteUser && deleteMutation.mutate({ id: deleteUser.id })}
            >
              {deleteMutation.isPending ? "กำลังลบ..." : "ลบสมาชิก"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
