import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq, or, ilike, sql } from "drizzle-orm";
import { authenticate, requireAdmin } from "../middlewares/auth.js";

const router = Router();

function formatUser(user: typeof usersTable.$inferSelect) {
  const { passwordHash: _, ...rest } = user;
  return { ...rest, createdAt: rest.createdAt.toISOString() };
}

// GET /users — admin only
router.get("/", authenticate, requireAdmin, async (req, res) => {
  try {
    const search = req.query.search as string | undefined;
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(100, parseInt(req.query.limit as string) || 20);
    const offset = (page - 1) * limit;

    let query = db.select().from(usersTable);

    if (search) {
      query = query.where(
        or(
          ilike(usersTable.firstName, `%${search}%`),
          ilike(usersTable.lastName, `%${search}%`),
          ilike(usersTable.email, `%${search}%`),
          ilike(usersTable.username, `%${search}%`),
          ilike(usersTable.houseNumber, `%${search}%`)
        )
      ) as typeof query;
    }

    const users = await query.limit(limit).offset(offset);
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(usersTable);

    return res.json({
      users: users.map(formatUser),
      total: count,
      page,
      totalPages: Math.ceil(count / limit),
    });
  } catch {
    return res.status(500).json({ error: "Failed to list users" });
  }
});

// POST /users — admin only
router.post("/", authenticate, requireAdmin, async (req, res) => {
  try {
    const { firstName, lastName, houseNumber, phone, email, username, password, role } = req.body;

    const existing = await db
      .select()
      .from(usersTable)
      .where(or(eq(usersTable.email, email), eq(usersTable.username, username)))
      .limit(1);

    if (existing.length > 0) {
      return res.status(400).json({ error: "Email or username already exists" });
    }

    const passwordHash = await bcrypt.hash(password || "changeme123", 12);
    const [user] = await db
      .insert(usersTable)
      .values({ firstName, lastName, houseNumber, phone, email, username, passwordHash, role: role || "member" })
      .returning();

    return res.status(201).json(formatUser(user));
  } catch {
    return res.status(500).json({ error: "Failed to create user" });
  }
});

// GET /users/:id
router.get("/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (req.user!.role !== "admin" && req.user!.userId !== id) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id)).limit(1);
    if (!user) return res.status(404).json({ error: "User not found" });

    return res.json(formatUser(user));
  } catch {
    return res.status(500).json({ error: "Failed to get user" });
  }
});

// PATCH /users/:id
router.patch("/:id", authenticate, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (req.user!.role !== "admin" && req.user!.userId !== id) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { firstName, lastName, houseNumber, phone, email, role } = req.body;
    const updates: Partial<typeof usersTable.$inferInsert> = {};

    if (firstName) updates.firstName = firstName;
    if (lastName) updates.lastName = lastName;
    if (houseNumber) updates.houseNumber = houseNumber;
    if (phone) updates.phone = phone;
    if (email) updates.email = email;
    if (role && req.user!.role === "admin") updates.role = role;

    const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, id)).returning();
    if (!user) return res.status(404).json({ error: "User not found" });

    return res.json(formatUser(user));
  } catch {
    return res.status(500).json({ error: "Failed to update user" });
  }
});

// DELETE /users/:id — admin only
router.delete("/:id", authenticate, requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(usersTable).where(eq(usersTable.id, id));
    return res.json({ message: "User deleted" });
  } catch {
    return res.status(500).json({ error: "Failed to delete user" });
  }
});

// POST /users/:id/reset-password — admin only
router.post("/:id/reset-password", authenticate, requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { newPassword } = req.body;

    if (!newPassword) return res.status(400).json({ error: "New password is required" });

    const passwordHash = await bcrypt.hash(newPassword, 12);
    await db.update(usersTable).set({ passwordHash }).where(eq(usersTable.id, id));

    return res.json({ message: "Password reset successfully" });
  } catch {
    return res.status(500).json({ error: "Failed to reset password" });
  }
});

export default router;
