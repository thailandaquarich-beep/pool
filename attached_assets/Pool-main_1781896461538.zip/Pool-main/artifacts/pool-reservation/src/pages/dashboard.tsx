import { FC } from "react";
import { useTranslation } from "@/i18n";
import { useAuth } from "@/hooks/use-auth";
import { useGetMemberStats, useGetUpcomingReservations } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CalendarDays, CalendarCheck, CalendarX, Activity } from "lucide-react";

export const Dashboard: FC = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { data: stats } = useGetMemberStats();
  const { data: upcoming } = useGetUpcomingReservations();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">{t("nav.dashboard")}</h1>
        <Button asChild>
          <Link href="/book">{t("dash.quickBook")}</Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t("dash.stats.total")}</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalReservations || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t("dash.stats.upcoming")}</CardTitle>
            <CalendarCheck className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.upcomingCount || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t("dash.stats.month")}</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.thisMonthCount || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t("dash.stats.cancelled")}</CardTitle>
            <CalendarX className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.cancelledCount || 0}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>{t("dash.nextReservation")}</CardTitle>
          </CardHeader>
          <CardContent>
            {upcoming && upcoming.length > 0 ? (
               <div className="bg-primary/5 p-6 rounded-lg border border-primary/10">
                 <div className="text-lg font-semibold">{upcoming[0].date}</div>
                 <div className="text-muted-foreground">{upcoming[0].startTime} - {upcoming[0].endTime}</div>
                 <div className="mt-4 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary text-primary-foreground">
                   {t("status.confirmed")}
                 </div>
               </div>
            ) : (
               <div className="text-center py-8 text-muted-foreground">
                 {t("dash.noUpcoming")}
               </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};