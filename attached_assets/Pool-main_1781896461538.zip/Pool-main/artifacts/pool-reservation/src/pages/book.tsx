import { FC, useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useGetAvailableSlots, useCreateReservation, getGetAvailableSlotsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { th } from "date-fns/locale";
import { CheckCircle2, Clock, Users, CalendarIcon, Waves, Minus, Plus, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

// Removed useTranslation as requested to hardcode Thai strings per spec
// (Actually the prompt says: "All Thai text for labels..." but I'll use it directly to keep it simple, or I'll just use Thai text directly as required)

export const Book: FC = () => {
  const [, setLocation] = useLocation();
  
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [people, setPeople] = useState<number>(1);
  const [notes, setNotes] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const slotSectionRef = useRef<HTMLDivElement>(null);
  const confirmSectionRef = useRef<HTMLDivElement>(null);

  const formattedDate = date ? format(date, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd");

  const { data: slots, isLoading } = useGetAvailableSlots(
    { date: formattedDate },
    { query: { queryKey: getGetAvailableSlotsQueryKey({ date: formattedDate }) } }
  );

  const createReservation = useCreateReservation();

  // Scroll to slot section when date is selected
  useEffect(() => {
    if (date && slotSectionRef.current && !selectedSlot && !isSuccess) {
      setTimeout(() => {
        slotSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }, [date, isSuccess]);

  // Scroll to confirm section when slot is selected
  useEffect(() => {
    if (selectedSlot && confirmSectionRef.current && !isSuccess) {
      setTimeout(() => {
        confirmSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }, [selectedSlot, isSuccess]);

  // Auto redirect after success
  useEffect(() => {
    if (isSuccess) {
      const timer = setTimeout(() => {
        setLocation("/reservations");
      }, 5000);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [isSuccess, setLocation]);

  const handleBook = () => {
    if (!selectedSlot || !date) return;
    
    const slot = slots?.find(s => s.startTime === selectedSlot);
    if (!slot) return;

    createReservation.mutate({
      data: {
        date: formattedDate,
        startTime: slot.startTime,
        endTime: slot.endTime,
        numberOfPeople: people,
        notes: notes || undefined
      }
    }, {
      onSuccess: () => {
        setIsSuccess(true);
      }
    });
  };

  const selectedSlotData = slots?.find(s => s.startTime === selectedSlot);
  
  const step = isSuccess ? 4 : selectedSlot ? 3 : date ? 2 : 1;

  if (isSuccess) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 rounded-full bg-emerald-100 flex items-center justify-center">
          <CheckCircle2 className="w-12 h-12 text-emerald-600" />
        </div>
        <h1 className="text-4xl font-bold tracking-tight text-emerald-950 dark:text-emerald-400">
          จองสำเร็จแล้ว!
        </h1>
        
        <div className="flex gap-4 w-full max-w-md">
          <Card className="flex-1 bg-white/50 backdrop-blur-sm border-emerald-100 dark:bg-emerald-950/20 dark:border-emerald-900">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center space-y-2">
              <CalendarIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <div className="text-sm font-medium">
                {date && format(date, "d MMM yyyy", { locale: th })}
              </div>
            </CardContent>
          </Card>
          <Card className="flex-1 bg-white/50 backdrop-blur-sm border-emerald-100 dark:bg-emerald-950/20 dark:border-emerald-900">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center space-y-2">
              <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <div className="text-sm font-medium">
                {selectedSlotData?.startTime} - {selectedSlotData?.endTime}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex gap-4">
          <Button onClick={() => setLocation("/reservations")} variant="outline" size="lg" className="rounded-full">
            ดูการจองของฉัน
          </Button>
          <Button onClick={() => {
            setIsSuccess(false);
            setDate(undefined);
            setSelectedSlot(null);
            setPeople(1);
            setNotes("");
          }} size="lg" className="rounded-full bg-emerald-600 hover:bg-emerald-700">
            จองอีกครั้ง
          </Button>
        </div>
        <p className="text-sm text-muted-foreground animate-pulse">กำลังพากลับไปหน้าการจองใน 5 วินาที...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Wavy/gradient header */}
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-cyan-50/50 to-background dark:from-primary/20 dark:via-cyan-900/20 dark:to-background py-16 px-4">
        <div className="max-w-4xl mx-auto space-y-6 relative z-10">
          {/* Step Indicator */}
          <div className="flex items-center justify-center space-x-2 sm:space-x-4 text-xs sm:text-sm font-medium text-muted-foreground">
            <span className={cn("transition-colors", step >= 1 ? "text-primary" : "")}>1 เลือกวัน</span>
            <span>&gt;</span>
            <span className={cn("transition-colors", step >= 2 ? "text-primary" : "")}>2 เลือกเวลา</span>
            <span>&gt;</span>
            <span className={cn("transition-colors", step >= 3 ? "text-primary" : "")}>3 ยืนยัน</span>
          </div>

          <div className="text-center space-y-2">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-cyan-600">
              จองสระว่ายน้ำ
            </h1>
            <p className="text-lg text-muted-foreground flex items-center justify-center gap-2">
              <Waves className="w-5 h-5 text-cyan-500" />
              เลือกวันที่ต้องการ
              <Waves className="w-5 h-5 text-cyan-500" />
            </p>
          </div>
        </div>
        
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] rounded-full bg-cyan-200/20 dark:bg-cyan-900/20 blur-3xl mix-blend-multiply" />
          <div className="absolute top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-blue-200/20 dark:bg-blue-900/20 blur-3xl mix-blend-multiply" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 space-y-12 -mt-8 relative z-20">
        {/* STEP 1: SELECT DATE */}
        <Card className="bg-card/80 backdrop-blur-sm border-border/50 shadow-xl overflow-hidden rounded-3xl">
          <CardContent className="p-6 md:p-8 flex flex-col items-center">
            <div className="w-full flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-primary" />
                เลือกวัน
              </h2>
              {date && (
                <div className="px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium animate-in fade-in slide-in-from-right-4">
                  เลือกแล้ว: {format(date, "d MMM yyyy", { locale: th })}
                </div>
              )}
            </div>
            
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-950 border shadow-sm">
              <Calendar
                mode="single"
                selected={date}
                onSelect={(d) => {
                  if (d) {
                    setDate(d);
                    setSelectedSlot(null);
                  }
                }}
                className="pointer-events-auto"
                classNames={{
                  months: "w-full",
                  month: "w-full space-y-4",
                  caption: "flex justify-center pt-1 relative items-center mb-4",
                  caption_label: "text-lg font-semibold",
                  nav: "space-x-1 flex items-center",
                  table: "w-full border-collapse space-y-1",
                  head_row: "flex w-full",
                  head_cell: "text-muted-foreground w-10 md:w-14 font-medium text-[0.8rem] text-center",
                  row: "flex w-full mt-2",
                  cell: "h-10 w-10 md:h-14 md:w-14 text-center text-sm p-0 relative focus-within:relative focus-within:z-20",
                  day: "h-full w-full p-0 font-normal aria-selected:opacity-100 hover:bg-muted rounded-xl transition-all",
                  day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground shadow-md scale-105",
                  day_today: "bg-accent text-accent-foreground font-bold",
                  day_outside: "text-muted-foreground opacity-50",
                  day_disabled: "text-muted-foreground opacity-50 cursor-not-allowed",
                  day_hidden: "invisible",
                }}
                disabled={(d) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  return d < today;
                }}
              />
            </div>
          </CardContent>
        </Card>

        {/* STEP 2: SELECT SESSION */}
        <div ref={slotSectionRef} className={cn("transition-all duration-700 space-y-6", date ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8 pointer-events-none hidden")}>
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Clock className="w-6 h-6 text-primary" />
              เลือกช่วงเวลา
            </h2>
            {date && <span className="text-muted-foreground">{format(date, "d MMM yyyy", { locale: th })}</span>}
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center p-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : slots && slots.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {slots.map((slot) => {
                const isFull = slot.currentPeople >= slot.maxPeople;
                const isMaintenance = !slot.available;
                const isSelected = selectedSlot === slot.startTime;
                const pct = Math.round((slot.currentPeople / slot.maxPeople) * 100);
                
                let statusColor = "emerald";
                if (pct >= 80 || isFull) statusColor = "rose";
                else if (pct >= 50) statusColor = "amber";

                const isUnavailable = isFull || isMaintenance;

                return (
                  <div
                    key={slot.startTime}
                    role="button"
                    tabIndex={0}
                    onClick={() => !isUnavailable && setSelectedSlot(slot.startTime)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        if (!isUnavailable) setSelectedSlot(slot.startTime);
                      }
                    }}
                    className={cn(
                      "relative overflow-hidden rounded-2xl border-2 p-5 text-left transition-all duration-300",
                      isUnavailable ? "opacity-50 cursor-not-allowed bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800" : 
                      isSelected ? "bg-card border-primary ring-4 ring-primary/20 shadow-xl shadow-primary/10 scale-[1.02] z-10" : 
                      "bg-card hover:shadow-lg hover:scale-[1.01] cursor-pointer hover:border-primary/50 border-transparent shadow-sm",
                      !isUnavailable && !isSelected && statusColor === "emerald" && "border-emerald-100 dark:border-emerald-900/50",
                      !isUnavailable && !isSelected && statusColor === "amber" && "border-amber-100 dark:border-amber-900/50",
                      !isUnavailable && !isSelected && statusColor === "rose" && "border-rose-100 dark:border-rose-900/50"
                    )}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="text-2xl font-bold tracking-tight">
                        {slot.startTime} <span className="text-muted-foreground font-normal mx-1">—</span> {slot.endTime}
                      </div>
                      <div className={cn(
                        "px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider",
                        isMaintenance ? "bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300" :
                        isFull ? "bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-400" :
                        isSelected ? "bg-primary text-primary-foreground" :
                        statusColor === "emerald" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400" :
                        statusColor === "amber" ? "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-400" :
                        "bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-400"
                      )}>
                        {isMaintenance ? "ปิดปรับปรุง" : isFull ? "เต็มแล้ว" : isSelected ? "เลือกแล้ว" : "ว่าง"}
                      </div>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                        <div 
                          className={cn(
                            "h-full rounded-full",
                            statusColor === "emerald" ? "bg-emerald-500" :
                            statusColor === "amber" ? "bg-amber-500" :
                            "bg-rose-500"
                          )}
                          style={{ width: `${pct}%`, transition: 'width 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
                        />
                      </div>
                      <div className="flex justify-between text-sm font-medium text-muted-foreground">
                        <span>{slot.currentPeople} / {slot.maxPeople} ที่นั่ง</span>
                        <span>{pct}%</span>
                      </div>
                    </div>

                    {!isUnavailable && (
                      <div className={cn(
                        "text-sm font-semibold mt-4 text-center py-2 rounded-xl transition-colors",
                        isSelected ? "bg-primary/10 text-primary" : "bg-secondary text-secondary-foreground"
                      )}>
                        {isSelected ? "เลือกช่วงเวลานี้แล้ว" : "คลิกเพื่อเลือกช่วงเวลานี้"}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center p-12 bg-muted/50 rounded-2xl border-2 border-dashed">
              <p className="text-muted-foreground text-lg">ไม่พบช่วงเวลาในวันที่เลือก</p>
            </div>
          )}
        </div>

        {/* STEP 3: CONFIRM */}
        <div ref={confirmSectionRef} className={cn("transition-all duration-700", selectedSlot ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8 pointer-events-none hidden")}>
          <div className="flex items-center gap-2 mb-6">
            <CheckCircle2 className="w-6 h-6 text-primary" />
            <h2 className="text-2xl font-bold">ยืนยันการจอง</h2>
          </div>

          <Card className="bg-card/80 backdrop-blur-sm border-border/50 shadow-xl overflow-hidden rounded-3xl">
            <CardContent className="p-6 md:p-8 space-y-8">
              {/* Summary Card */}
              <div className="bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 p-6 rounded-2xl border border-blue-100 dark:border-blue-900 flex flex-col sm:flex-row items-center gap-6">
                <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center shrink-0">
                  <Waves className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="text-center sm:text-left space-y-1">
                  <h3 className="text-xl font-bold text-blue-950 dark:text-blue-100">Aquarich Pool</h3>
                  <p className="text-blue-800/80 dark:text-blue-300 font-medium">
                    {date && format(date, "d MMMM yyyy", { locale: th })} • {selectedSlotData?.startTime} - {selectedSlotData?.endTime}
                  </p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                {/* Stepper */}
                <div className="space-y-4">
                  <label className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">จำนวนผู้ใช้งาน</label>
                  <div className="flex items-center p-2 bg-secondary rounded-2xl w-fit">
                    <button 
                      onClick={() => setPeople(Math.max(1, people - 1))}
                      disabled={people <= 1}
                      className="w-12 h-12 rounded-xl bg-background shadow-sm flex items-center justify-center text-foreground hover:bg-accent disabled:opacity-50 disabled:cursor-not-allowed transition-colors min-w-[48px] min-h-[48px]"
                    >
                      <Minus className="w-5 h-5" />
                    </button>
                    <div className="w-20 text-center text-3xl font-bold">
                      {people}
                    </div>
                    <button 
                      onClick={() => setPeople(Math.min(10, Math.min(selectedSlotData ? selectedSlotData.maxPeople - selectedSlotData.currentPeople : 10, people + 1)))}
                      disabled={people >= 10 || (selectedSlotData && people >= selectedSlotData.maxPeople - selectedSlotData.currentPeople)}
                      className="w-12 h-12 rounded-xl bg-background shadow-sm flex items-center justify-center text-foreground hover:bg-accent disabled:opacity-50 disabled:cursor-not-allowed transition-colors min-w-[48px] min-h-[48px]"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                  <p className="text-sm text-muted-foreground flex items-center gap-1.5">
                    <Users className="w-4 h-4" />
                    จองได้สูงสุด 10 ท่านต่อครั้ง
                  </p>
                </div>

                {/* Notes */}
                <div className="space-y-4">
                  <label className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">หมายเหตุ (ถ้ามี)</label>
                  <Textarea 
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="เช่น ต้องการเก้าอี้ผ้าใบเพิ่ม..."
                    className="resize-none rounded-2xl min-h-[120px] bg-secondary/50 border-transparent focus:bg-background transition-colors"
                  />
                </div>
              </div>

            </CardContent>
          </Card>
        </div>
      </div>

      {/* Sticky Bottom CTA for Mobile & Desktop */}
      {selectedSlot && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/80 backdrop-blur-xl border-t z-50 animate-in slide-in-from-bottom-full duration-500">
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <p className="text-sm font-medium text-muted-foreground mb-1">
                ที่นั่งว่างอีก {selectedSlotData ? selectedSlotData.maxPeople - selectedSlotData.currentPeople : 0} ที่
              </p>
              <p className="text-lg font-bold">
                รวม {people} ท่าน
              </p>
            </div>
            
            <Button 
              size="lg"
              onClick={handleBook}
              disabled={createReservation.isPending}
              className="w-full sm:w-auto min-h-[56px] px-8 rounded-full bg-gradient-to-r from-primary to-cyan-500 hover:from-primary/90 hover:to-cyan-500/90 text-white shadow-lg shadow-primary/25 text-lg font-bold transition-all hover:scale-105"
            >
              {createReservation.isPending ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> กำลังดำเนินการ...</>
              ) : (
                "ยืนยันการจอง"
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
