import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import reservationsRouter from "./reservations";
import settingsRouter from "./settings";
import statsRouter from "./stats";
import facilitiesRouter from "./facilities";
import instructorsRouter from "./instructors";
import announcementsRouter from "./announcements";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/reservations", reservationsRouter);
router.use("/settings", settingsRouter);
router.use("/stats", statsRouter);
router.use("/facilities", facilitiesRouter);
router.use("/instructors", instructorsRouter);
router.use("/announcements", announcementsRouter);

export default router;
