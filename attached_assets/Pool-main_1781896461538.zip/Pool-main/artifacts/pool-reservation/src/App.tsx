import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { LanguageProvider } from "@/i18n";
import { ThemeProvider } from "@/hooks/use-theme";
import { AppLayout } from "@/components/layout/app-layout";
import NotFound from "@/pages/not-found";

import { Login } from "@/pages/login";
import { Register } from "@/pages/register";
import { Dashboard } from "@/pages/dashboard";
import { AdminDashboard } from "@/pages/admin/dashboard";
import { Reservations } from "@/pages/reservations";
import { Book } from "@/pages/book";
import { Calendar } from "@/pages/calendar";
import { Profile } from "@/pages/profile";

import { AdminMembers } from '@/pages/admin/members'
import { AdminReservations } from '@/pages/admin/reservations'
import { AdminSettings } from '@/pages/admin/settings'
import { AdminFacilities } from '@/pages/admin/facilities'
import { AdminInstructors } from '@/pages/admin/instructors'
import { AdminAnnouncements } from '@/pages/admin/announcements'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

const ProtectedRoute = ({ component: Component, adminOnly = false, ...rest }: any) => {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  if (adminOnly && !isAdmin) {
    return <Redirect to="/dashboard" />;
  }

  if (!adminOnly && isAdmin && rest.path === "/dashboard") {
     return <Redirect to="/admin" />;
  }

  return <Component />;
};

function Router() {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <AppLayout>
      <Switch>
        <Route path="/">
          {isAuthenticated ? <Redirect to={isAdmin ? "/admin" : "/dashboard"} /> : <Login />}
        </Route>
        <Route path="/register">
          {isAuthenticated ? <Redirect to={isAdmin ? "/admin" : "/dashboard"} /> : <Register />}
        </Route>
        
        <Route path="/dashboard"><ProtectedRoute component={Dashboard} /></Route>
        <Route path="/reservations"><ProtectedRoute component={Reservations} /></Route>
        <Route path="/book"><ProtectedRoute component={Book} /></Route>
        <Route path="/calendar"><ProtectedRoute component={Calendar} /></Route>
        <Route path="/profile"><ProtectedRoute component={Profile} /></Route>
        
        <Route path="/admin"><ProtectedRoute component={AdminDashboard} adminOnly /></Route>
        <Route path="/admin/members"><ProtectedRoute component={AdminMembers} adminOnly /></Route>
        <Route path="/admin/reservations"><ProtectedRoute component={AdminReservations} adminOnly /></Route>
        <Route path="/admin/settings"><ProtectedRoute component={AdminSettings} adminOnly /></Route>
        <Route path="/admin/facilities"><ProtectedRoute component={AdminFacilities} adminOnly /></Route>
        <Route path="/admin/instructors"><ProtectedRoute component={AdminInstructors} adminOnly /></Route>
        <Route path="/admin/announcements"><ProtectedRoute component={AdminAnnouncements} adminOnly /></Route>
        
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <AuthProvider>
            <LanguageProvider>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <Router />
              </WouterRouter>
              <Toaster />
            </LanguageProvider>
          </AuthProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;