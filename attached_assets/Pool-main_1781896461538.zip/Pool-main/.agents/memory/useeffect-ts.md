---
name: useEffect conditional return TypeScript
description: TypeScript strict mode requires explicit return in all code paths of useEffect
---

## Rule
When useEffect has a conditional cleanup function, always add `return undefined;` in the else branch.

```ts
useEffect(() => {
  if (condition) {
    const timer = setTimeout(...);
    return () => clearTimeout(timer);
  }
  return undefined; // required for TypeScript strict
}, [condition]);
```
