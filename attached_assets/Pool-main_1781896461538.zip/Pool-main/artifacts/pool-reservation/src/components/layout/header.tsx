import { FC, useState } from "react";
import { useTranslation } from "@/i18n";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/hooks/use-theme";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Link, useLocation } from "wouter";
import {
  Menu,
  Droplets,
  LayoutDashboard,
  CalendarDays,
  CalendarPlus,
  Calendar,
  User,
  Settings,
  Users,
  LogOut,
  ChevronRight,
  Sun,
  Moon,
  Building2,
  GraduationCap,
  Bell
} from "lucide-react";
import { cn } from "@/lib/utils";

export const Header: FC = () => {
  const { language, setLanguage, t } = useTranslation();
  const { user, isAdmin, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  const toggleLanguage = () => {
    setLanguage(language === "th" ? "en" : "th");
  };

  const memberLinks = [
    { href: "/dashboard", label: t("nav.dashboard"), icon: LayoutDashboard },
    { href: "/reservations", label: t("nav.reservations"), icon: CalendarDays },
    { href: "/book", label: t("nav.book"), icon: CalendarPlus },
    { href: "/calendar", label: t("nav.calendar"), icon: Calendar },
    { href: "/profile", label: t("nav.profile"), icon: User },
  ];

  const adminLinks = [
    { href: "/admin", label: t("nav.admin.dashboard"), icon: LayoutDashboard },
    { href: "/admin/reservations", label: t("nav.admin.reservations"), icon: CalendarDays },
    { href: "/admin/members", label: t("nav.admin.members"), icon: Users },
    { href: "/admin/facilities", label: t("nav.admin.facilities"), icon: Building2 },
    { href: "/admin/instructors", label: t("nav.admin.instructors"), icon: GraduationCap },
    { href: "/admin/announcements", label: t("nav.admin.announcements"), icon: Bell },
    { href: "/admin/settings", label: t("nav.admin.settings"), icon: Settings },
  ];

  const links = isAdmin ? adminLinks : memberLinks;

  const handleNavClick = () => setOpen(false);

  const handleLogout = () => {
    setOpen(false);
    logout();
  };

  return (
    <header className="h-16 border-b border-border bg-card/80 backdrop-blur-sm flex items-center justify-between px-4 md:px-6 sticky top-0 z-30">
      {/* Mobile hamburger */}
      <div className="flex items-center md:hidden">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="-ml-2"
              data-testid="button-mobile-menu"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0 flex flex-col">
            <SheetHeader className="p-4 border-b border-border">
              <SheetTitle className="flex items-center gap-3">
                <img src="/aquarich-logo.png" alt="Aquarich" className="w-9 h-9 object-contain flex-shrink-0" />
                <div className="text-left">
                  <div className="font-semibold text-foreground text-sm bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">Aquarich</div>
                  <div className="text-xs text-muted-foreground">Reservation System</div>
                </div>
              </SheetTitle>
            </SheetHeader>

            {/* User info */}
            {user && (
              <div className="px-4 py-3 bg-primary/5 border-b border-border">
                <div className="text-sm font-medium text-foreground">
                  {user.firstName} {user.lastName}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {t("nav.house")} {user.houseNumber} · {isAdmin ? "Admin" : "Member"}
                </div>
              </div>
            )}

            {/* Navigation */}
            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              {links.map((link) => {
                const isActive = location === link.href;
                const Icon = link.icon;
                return (
                  <Link key={link.href} href={link.href}>
                    <div
                      onClick={handleNavClick}
                      className={cn(
                        "flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                        isActive
                          ? "bg-primary text-primary-foreground"
                          : "text-foreground hover:bg-accent hover:text-accent-foreground"
                      )}
                      data-testid={`link-mobile-${link.href.replace(/\//g, "-")}`}
                    >
                      <Icon className="w-5 h-5 shrink-0" />
                      <span className="flex-1">{link.label}</span>
                      {isActive && <ChevronRight className="w-4 h-4 opacity-60" />}
                    </div>
                  </Link>
                );
              })}
            </nav>

            {/* Bottom actions */}
            <div className="p-3 border-t border-border space-y-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleTheme}
                className="w-full justify-start font-medium text-sm"
              >
                {theme === "dark" ? <Sun className="w-4 h-4 mr-2" /> : <Moon className="w-4 h-4 mr-2" />}
                {t("theme.toggle")}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleLanguage}
                className="w-full justify-start font-medium text-sm"
                data-testid="button-mobile-language"
              >
                {language === "th" ? "🌐 English" : "🌐 ภาษาไทย"}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10 font-medium text-sm"
                onClick={handleLogout}
                data-testid="button-mobile-logout"
              >
                <LogOut className="w-4 h-4 mr-2" />
                {t("nav.logout")}
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop: greeting */}
      <div className="hidden md:flex items-center text-sm text-muted-foreground">
        {user
          ? `${t("dash.welcome")}, ${user.firstName} ${user.lastName}`
          : ""}
      </div>

      {/* Right side actions */}
      <div className="flex items-center gap-2 ml-auto">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleTheme}
          title={t("theme.toggle")}
        >
          {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={toggleLanguage}
          className="font-medium"
          data-testid="button-language-toggle"
        >
          {language === "th" ? "EN" : "ไทย"}
        </Button>

        {/* Desktop logout button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={logout}
          className="hidden md:flex items-center gap-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          data-testid="button-desktop-logout"
        >
          <LogOut className="w-4 h-4" />
          <span className="hidden lg:inline">{t("nav.logout")}</span>
        </Button>
      </div>
    </header>
  );
};