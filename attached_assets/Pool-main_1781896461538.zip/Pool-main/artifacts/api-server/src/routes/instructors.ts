import { Router } from "express";
import { db, instructorsTable } from "@workspace/db";
import { eq, ilike, or, sql } from "drizzle-orm";
import { authenticate, requireAdmin } from "../middlewares/auth.js";

const router = Router();

// GET /instructors — authenticated
router.get("/", authenticate, async (req, res) => {
  try {
    const search = req.query.search as string | undefined;
    const status = req.query.status as string | undefined;

    let query = db.select().from(instructorsTable);
    if (status) {
      query = query.where(eq(instructorsTable.status, status as "active" | "on_leave" | "inactive")) as typeof query;
    } else if (search) {
      query = query.where(
        or(ilike(instructorsTable.firstName, `%${search}%`), ilike(instructorsTable.lastName, `%${search}%`), ilike(instructorsTable.specialty, `%${search}%`))
      ) as typeof query;
    }

    const instructors = await query.orderBy(instructorsTable.firstName);
    return res.json(instructors);
  } catch {
    return res.status(500).json({ error: "Failed to list instructors" });
  }
});

// GET /instructors/:id
router.get("/:id", authenticate, async (req, res) => {
  try {
    const [instructor] = await db.select().from(instructorsTable).where(eq(instructorsTable.id, parseInt(req.params.id))).limit(1);
    if (!instructor) return res.status(404).json({ error: "Instructor not found" });
    return res.json(instructor);
  } catch {
    return res.status(500).json({ error: "Failed to get instructor" });
  }
});

// POST /instructors — admin only
router.post("/", authenticate, requireAdmin, async (req, res) => {
  try {
    const { firstName, lastName, phone, email, specialty, certification, experience, biography, profileImageUrl, status } = req.body;
    const [instructor] = await db
      .insert(instructorsTable)
      .values({ firstName, lastName, phone, email, specialty, certification, experience, biography, profileImageUrl, status: status || "active" })
      .returning();
    return res.status(201).json(instructor);
  } catch {
    return res.status(500).json({ error: "Failed to create instructor" });
  }
});

// PATCH /instructors/:id — admin only
router.patch("/:id", authenticate, requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const updates: Partial<typeof instructorsTable.$inferInsert> = {};
    const fields = ["firstName", "lastName", "phone", "email", "specialty", "certification", "experience", "biography", "profileImageUrl", "status"] as const;
    for (const f of fields) {
      if (req.body[f] !== undefined) (updates as any)[f] = req.body[f];
    }
    const [instructor] = await db.update(instructorsTable).set(updates).where(eq(instructorsTable.id, id)).returning();
    if (!instructor) return res.status(404).json({ error: "Instructor not found" });
    return res.json(instructor);
  } catch {
    return res.status(500).json({ error: "Failed to update instructor" });
  }
});

// DELETE /instructors/:id — admin only
router.delete("/:id", authenticate, requireAdmin, async (req, res) => {
  try {
    await db.delete(instructorsTable).where(eq(instructorsTable.id, parseInt(req.params.id)));
    return res.json({ message: "Instructor deleted" });
  } catch {
    return res.status(500).json({ error: "Failed to delete instructor" });
  }
});

export default router;
